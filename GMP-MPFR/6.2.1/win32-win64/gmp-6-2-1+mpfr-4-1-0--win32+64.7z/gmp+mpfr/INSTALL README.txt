to install the files to your FreeBasic distribution simply drag and drop the FreeBasic folder on top of drag&dropFBfolder.bat
